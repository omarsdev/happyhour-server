// const express = require("express");
// const admin = require("firebase-admin");

// const router = express.Router();
// const serviceAccount = require("../config/firebase.json");
// const User = require("../model/User");

// admin.initializeApp({
//   credential: admin.credential.cert(serviceAccount),
// });
// let tokens = [
//   "dVzenmCZRnObNAoT_Es3Ir:APA91bEbPPcp5tC0UXimCXngc3GFvpjS3rT7hHbtO-AMXUltriMiHDlbg0UrDADvXVSW7Y3mwneEW2x2MLl-tlNSXVHlDTArf4zCd9Iy4vcvbZCsj7n6_jmYJEF3xWYJhnsYZpTPAT6V",
//   "dA88nqFqS06JPwHsYx9-zU:APA91bHEagIQ9I_l6VpPHxPrTYTUCMj_hOpgTmUb4WAhGK3YMGsFLKRNIy_9rx0I_OUNrRIzMPh1tCD1vIGGs2HAt1pPLumPyhUsPwoE3a_w9RlQDt2UltjMqdehlP869-aALpAOyi63",
//   ,
//   "eTPaUacFTuWpCtpYG75L9N:APA91bHvp5V-KL0iPfIFQY6FCxqIojhFa2kuzSxXjcYJyJaFkZ5V2W2M6bIWewcKnlPDl2DQVvXEUqNPUqu4z5ODwLsiFfPGklVmW8DsKb4KHmlhInQ0carTSUr2P-a1V8P-DG7Lc_s1",
// ];
// // console.log(tokens);
// // router.post("/post", (req, res) => {
// //   tokens.push(req.body.token);
// //   res.status(200).json({ message: "Successfully registered FCM Token!" });
// // });

// // router.route("/register").post((req, res) => {
// //   tokens.push(req.body.token);
// //   console.log(tokens);

// //   res.status(200).json({ message: "Successfully registered FCM Token!" });
// // });

// router.route("/notifications").post(async (req, res) => {
//   try {
//     const { title, body, imageUrl } = req.body;
//     // const user = await User.findOne({ phone_number: "0933166278" }).select(
//     //   "notificationToken"
//     // );
//     // tokens.push(user.notificationToken[0]);
//     // console.log(tokens);
//     await admin.messaging().sendMulticast({
//       tokens,
//       notification: {
//         title,
//         body,
//         imageUrl,
//       },
//     });
//     res.status(200).json({ message: "Successfully sent notifications!" });
//   } catch (err) {
//     res
//       .status(err.status || 500)
//       .json({ message: err.message || "Something went wrong!" });
//   }
// });

// // router.post("/notifications", async (req, res) => {
// //   try {
// //     const { title, body, imageUrl } = req.body;
// //     await admin.messaging().sendMulticast({
// //       tokens,
// //       notification: {
// //         title,
// //         body,
// //         imageUrl,
// //       },
// //     });
// //     res.status(200).json({ message: "Successfully sent notifications!" });
// //   } catch (err) {
// //     res
// //       .status(err.status || 500)
// //       .json({ message: err.message || "Something went wrong!" });
// //   }
// // });

// module.exports = router;
