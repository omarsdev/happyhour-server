const express = require("express");

//import autherizetion
const { protect, authorize, protectEmployee } = require("../middleware/auth");

const {
  getAllStore,
  checkStoreTest,
  addHappyStore,
  removeHappyStore,
  addIWantThis,
  removeIWantThis,
  addUserRate,
} = require("../Controller/Store.Controller");
const multer = require("multer");

const fileStorage = multer.diskStorage({
  destination: "images/test",
});
const upload = multer({
  storage: fileStorage,
});

const router = express.Router();

router
  .route("/:brandid")
  .get(getAllStore)
  // .post(protect, authorize("client"), createStore);
  .post(protect, authorize("client"), checkStoreTest);
router.route("/sethappy/:storeid").post(protect, addHappyStore);
router.route("/removehappy/:storeid").post(protect, removeHappyStore);

router.route("/setiwantthis/:storeid").post(protect, addIWantThis);
router.route("/removeiwantthis/:storeid").post(protect, removeIWantThis);
// router.route("/teststore", upload.single("photo")).post(testStore);

//Rate User
router.route("/addrate/:storeid").post(protect, addUserRate);

module.exports = router;
